#ifndef MAIN_H
#define MAIN_H

#include <unistd.h>
#include <sys/wait.h>
#include "phase1.h"
#include "phase2.h"
#include "phase3.h"
#include "phase4.h"

#endif
