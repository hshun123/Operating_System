// Add Guard to header file (google what are guards)
// Function prototypes to
//			Traverse the Folder
//			Partition the text file paths to 'm' files
#ifndef PAHSE_1
#define PHASE_1

void your_recursive_func(const char *curr_dir, int indent);

void process (const char *curr_dir, int m);

#endif
