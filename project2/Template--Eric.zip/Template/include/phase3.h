// Add Guard to header file
// Function prototype for 
//			reduce function that will receive list from all the Mappers to create a single list
//			the single list is then written to ReducerResult.txt