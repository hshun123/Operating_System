// Add Guard to header file
// Function prototypes for
//			Master process's reporting procedure
